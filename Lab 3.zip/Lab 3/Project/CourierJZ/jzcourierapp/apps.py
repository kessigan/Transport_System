from django.apps import AppConfig


class JzcourierappConfig(AppConfig):
    name = 'jzcourierapp'

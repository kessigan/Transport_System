1) Go to: github.com/kessigan/Transport_System
2) clone the repo by going copying the https link to the repo. The link is https://github.com/kessigan/Transport_System.git
3) Go to the terminal and type in: git clone https://github.com/kessigan/Transport_System.git
4) Go to the folder Lab3
